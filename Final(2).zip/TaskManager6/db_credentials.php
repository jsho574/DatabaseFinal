<?php
$servername = "sql303.epizy.com";// 185.27.134.11
$username = "epiz_20659276";
$password = "8iW7SGKVky";
$dbname = "epiz_20659276_FinalProject";
?>